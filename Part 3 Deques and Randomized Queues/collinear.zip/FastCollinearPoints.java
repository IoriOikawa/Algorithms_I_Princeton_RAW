import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.StdDraw;
import edu.princeton.cs.algs4.StdOut;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class FastCollinearPoints {
    private final LineSegment[] lineSegment;
    
    // finds all line segments containing 4 points
    public FastCollinearPoints(Point[] points) {
        // check if the whole array is null
        if (points == null) throw new IllegalArgumentException();

        // check duplicated or null point
        if (points[0] == null) {
            throw new IllegalArgumentException();
        }
        for (int i = 0; i < points.length - 1; i++) {
            for (int j = i + 1; j < points.length; j++) {
                if (points[j] == null) {
                    throw new IllegalArgumentException();
                }
                if (points[i].compareTo(points[j]) == 0) {
                    throw new IllegalArgumentException();
                }
            }
        }
        
        if (points.length < 4) {
            this.lineSegment = new LineSegment[0];
            return;
        }
        
        points = Arrays.copyOf(points, points.length);
        Arrays.sort(points, new Comparator<Point>() {
            @Override
            public int compare(Point p1, Point p2) {
                return p1.compareTo(p2);
            }
        });
        
        List<LineSegment> tmpLineSegment = new ArrayList<LineSegment>();
        List<Point> searchFrontier = new ArrayList<Point>();
        for (int i = 0; i < points.length; i++) {
            searchFrontier.add(points[i]);
        }
        
        while (searchFrontier.size() > 0) {
            List<Point> addToFrontier = new ArrayList<Point>();
            
            // sort them by slope order of current search frontier
            Point p = searchFrontier.get(0);
            Point[] pointBySlopeOrder = Arrays.copyOf(points, points.length);
            Arrays.sort(pointBySlopeOrder, p.slopeOrder());
            
            // Check if any 3 (or more) adjacent points in the sorted order
            // have equal slopes with respect to p. 
            // If so, these points, together with p, are collinear.
            double lastSlope = Double.NEGATIVE_INFINITY;
            int lastIndex = 0;
            
            for (int q = 0; q < pointBySlopeOrder.length; q++) {
                if (p == pointBySlopeOrder[q]) {
                    continue;
                }
                double currentSlope = p.slopeTo(pointBySlopeOrder[q]);
                
                Boolean foundCol = false;
                int maxIndexOfI = -1;
                if (q == pointBySlopeOrder.length - 1) {
                    if (lastSlope == currentSlope && q - lastIndex >= 2) {
                        foundCol = true;
                        maxIndexOfI = pointBySlopeOrder.length - 1;
                    }
                }
                if (lastSlope != currentSlope) {
                    if (q - lastIndex >= 3) {
                        foundCol = true;
                        maxIndexOfI = q - 1;
                    } else {
                        lastIndex = q;
                        lastSlope = currentSlope;
                    }
                }
                
                if (foundCol) {
                    List<Point> col = new ArrayList<Point>();
                    col.add(p);
                    for (int i = lastIndex; i <= maxIndexOfI; i++) {
                        col.add(pointBySlopeOrder[i]);
                    }
                    
                    Point[] colPoints = new Point[col.size()];
                    col.toArray(colPoints);
                    colPoints = Arrays.copyOf(colPoints, colPoints.length);
                    Arrays.sort(colPoints, new Comparator<Point>() {
                        @Override
                        public int compare(Point p1, Point p2) {
                            return p1.compareTo(p2);
                        }
                    });

                    tmpLineSegment.add(new LineSegment(colPoints[0], colPoints[colPoints.length - 1]));
                    addToFrontier.add(colPoints[colPoints.length - 1]);
                    
                    lastIndex = q;
                    lastSlope = currentSlope;
                }
            }
            
            
            List<Point> pointsList = new ArrayList<Point>();
            for (int i = 0; i < points.length; i++) {
                pointsList.add(points[i]);
            }
            pointsList.remove(pointsList.indexOf(p));
            points = new Point[pointsList.size()];
            pointsList.toArray(points);
            
            for (int i = 0; i < addToFrontier.size(); i++) {
                searchFrontier.add(0, addToFrontier.get(i));
            }
            int index = searchFrontier.indexOf(p);
            while (index != -1) {
                searchFrontier.remove(index);
                index = searchFrontier.indexOf(p);
            }
            
        }
        
        this.lineSegment = new LineSegment[tmpLineSegment.size()];
        tmpLineSegment.toArray(this.lineSegment);
    }
    
    // the number of line segments
    public int numberOfSegments() {
        return this.lineSegment.length;
    }
    
    // the line segments
    public LineSegment[] segments() {
        return Arrays.copyOf(this.lineSegment, this.numberOfSegments());
    }
    
    public static void main(String[] args) {
        // read the n points from a file
        In in = new In(args[0]);
        int n = in.readInt();
        Point[] points = new Point[n];
        for (int i = 0; i < n; i++) {
            int x = in.readInt();
            int y = in.readInt();
            points[i] = new Point(x, y);
        }

        // draw the points
        StdDraw.enableDoubleBuffering();
        StdDraw.setXscale(0, 32768);
        StdDraw.setYscale(0, 32768);
        for (Point p : points) {
            p.draw();
        }
        StdDraw.show();

        // print and draw the line segments
        FastCollinearPoints collinear = new FastCollinearPoints(points);
        for (LineSegment segment : collinear.segments()) {
            StdOut.println(segment);
            segment.draw();
        }
        StdDraw.show();
    }
}
