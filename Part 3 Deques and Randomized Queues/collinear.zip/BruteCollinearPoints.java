import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.StdDraw;
import edu.princeton.cs.algs4.StdOut;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class BruteCollinearPoints {
    private final LineSegment[] lineSegment;
    
    // finds all line segments containing 4 points
    public BruteCollinearPoints(Point[] points) {
        // check if the whole array is null
        if (points == null) throw new IllegalArgumentException();

        // check duplicated or null point
        if (points[0] == null) {
            throw new IllegalArgumentException();
        }
        for (int i = 0; i < points.length - 1; i++) {
            for (int j = i + 1; j < points.length; j++) {
                if (points[j] == null) {
                    throw new IllegalArgumentException();
                }
                if (points[i].compareTo(points[j]) == 0) {
                    throw new IllegalArgumentException();
                }
            }
        }
        
        points = Arrays.copyOf(points, points.length);
        // sort them by X, then by Y
        Arrays.sort(points, new Comparator<Point>() {
            @Override
            public int compare(Point p1, Point p2) {
                return p1.compareTo(p2);
            }
        });
        
        List<LineSegment> tmpLineSegment = new ArrayList<LineSegment>();
        for (int p = 0; p < points.length - 3; p++) {
            for (int q = p + 1; q < points.length - 2; q++) {
                for (int r = q + 1; r < points.length - 1; r++) {
                    for (int s = r + 1; s < points.length; s++) {
                        double s1 = points[p].slopeTo(points[q]);
                        double s2 = points[p].slopeTo(points[r]);
                        if (s1 == s2) {
                            double s3 = points[p].slopeTo(points[s]);
                            if (s2 == s3) {
                                tmpLineSegment.add(new LineSegment(points[p], points[s]));
                            }
                        }
                    }
                }
            }
        }
        
        this.lineSegment = new LineSegment[tmpLineSegment.size()];
        tmpLineSegment.toArray(this.lineSegment);
    }
    
    // the number of line segments
    public int numberOfSegments() {
        return this.lineSegment.length;
    }
    
    // the line segments
    public LineSegment[] segments() {
        return Arrays.copyOf(this.lineSegment, this.numberOfSegments());
    }
    
    public static void main(String[] args) {
        // read the n points from a file
        In in = new In(args[0]);
        int n = in.readInt();
        Point[] points = new Point[n];
        for (int i = 0; i < n; i++) {
            int x = in.readInt();
            int y = in.readInt();
            points[i] = new Point(x, y);
        }

        // draw the points
        StdDraw.enableDoubleBuffering();
        StdDraw.setXscale(0, 32768);
        StdDraw.setYscale(0, 32768);
        for (Point p : points) {
            p.draw();
        }
        StdDraw.show();

        // print and draw the line segments
        BruteCollinearPoints collinear = new BruteCollinearPoints(points);
        for (LineSegment segment : collinear.segments()) {
            StdOut.println(segment);
            segment.draw();
        }
        StdDraw.show();
    }
}
